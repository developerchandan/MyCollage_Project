<?php
 
$framework = radium_framework();
 
require_once( $framework -> theme_framework_dir . '/sidebars/classes/class.widgetclass.php' );
 
$radium_widget_class = new Radium_WidgetClass();
 